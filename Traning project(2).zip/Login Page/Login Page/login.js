document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    if (!username.value || !password.value) {
        alert('Username and password are mandatory');
        if (!username.value) {
            username.focus();
        } else if (!password.value) {
            password.focus();
        }
        return;
    }
    const user = {
        userName: username.value,
        pwd: password.value
    };
    console.log(user); // Log the user object to the console

    // Validate the username and password against the data in local storage
    const userList = JSON.parse(localStorage.getItem('userList')) || [];
    const existingUser = userList.find(user => user.userName === username.value);
    if (!existingUser) {
        alert('User Name not Present');
    } else if (existingUser.pwd !== password.value) {
        alert('Password Wrong Please try Again');
    } else {
        alert('Login successful');
    }
});

document.getElementById('resetBtn').addEventListener('click', function() {
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    console.log('Username and password fields have been cleared'); // Log a message to the console
});

document.getElementById('signUpBtn').addEventListener('click', function() {
    window.location.href = 'signup.html';
});

document.getElementById('passwordResetBtn').addEventListener('click', function() {
    window.location.href = 'reset.html';
});

document.getElementById('username').addEventListener('blur', function() {
    this.style.borderColor = this.value ? 'initial' : 'red';
});

document.getElementById('password').addEventListener('blur', function() {
    this.style.borderColor = this.value ? 'initial' : 'red';
});

setInterval(function() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    document.getElementById('submitBtn').disabled = !username && !password;
    document.getElementById('resetBtn').style.display = username || password ? 'initial' : 'none';
}, 100);