function showAlert(message, isError = false) {
    const alertElement = document.getElementById('alert');
    alertElement.innerHTML = message;

    if (isError) {
        alertElement.classList.add('alert-danger');
    } else {
        alertElement.classList.remove('alert-danger');
    }

    $('#alertModal').modal('show');

    setTimeout(function () {
        $('#alertModal').modal('hide');
    }, 5000);
}

document.getElementById('signupForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Validate username
    if (!username) {
        showAlert('Username is mandatory', true);
        document.getElementById('username').focus();
        return;
    }

    // Validate password
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^])[a-zA-Z!@#$%^0-9]{8,}$/;
    if (!passwordRegex.test(password)) {
        showAlert('Password should have at least 8 characters, 1 lowercase letter, 1 uppercase letter, and 1 special character (!@#$%^)', true);
        document.getElementById('password').focus();
        return;
    }

    // Rest of the signup logic
    const userList = JSON.parse(localStorage.getItem('userList')) || [];
    const userExists = userList.find(user => user.userName === username);

    if (userExists) {
        showAlert('User Name already taken, choose another Name and Try Again', true);
        document.getElementById('username').focus();
    } else {
        const user = {
            userName: username,
            pwd: password
        };

        userList.push(user);
        localStorage.setItem('userList', JSON.stringify(userList));
        showAlert('User is Created');

        // Log the userList to the console
        console.log(userList);

    
        $('#signupModal').modal('hide');
    }
});

const resetButton = document.getElementById('resetBtn');
if (resetButton) {
    resetButton.addEventListener('click', function () {
        localStorage.clear();
        showAlert('Storage cleared');
    });
}

// Disable copy/paste for password field
document.getElementById('password').addEventListener('paste', function (e) {
    e.preventDefault();
});

// Disable right-click for password field
document.getElementById('password').addEventListener('contextmenu', function (e) {
    e.preventDefault();
});

// Disable shortcuts for copy/paste on password field
document.getElementById('password').addEventListener('keydown', function (e) {
    if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
    }
});
