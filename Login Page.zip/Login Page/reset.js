const userList = JSON.parse(localStorage.getItem('userList')) || [];

document.getElementById('resetForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const newPassword = document.getElementById('newPassword').value;
    if (!username || !newPassword) {
        alert('Username and new password are mandatory');
        if (!username) {
            document.getElementById('username').focus();
        } else if (!newPassword) {
            document.getElementById('newPassword').focus();
        }
    } else {
        const userIndex = userList.findIndex(user => user.userName === username);
        if (userIndex === -1) {
            alert('User Name not found');
            document.getElementById('username').focus();
        } else {
            userList[userIndex].pwd = newPassword;
            localStorage.setItem('userList', JSON.stringify(userList));
            alert('Password is reset');
        }
    }
});

document.getElementById('resetBtn').addEventListener('click', function() {
    document.getElementById('username').value = '';
    document.getElementById('newPassword').value = '';
});