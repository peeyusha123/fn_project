function showAlert(message) {
    const alertElement = document.getElementById('alert');
    alertElement.innerHTML = message;
    $('#alertModal').modal('show');
    setTimeout(function() {
        $('#alertModal').modal('hide');
    }, 5000);
}

document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    if (!username || !password) {
        showAlert('Username and password are mandatory');
        if (!username) {
            document.getElementById('username').focus();
        } else if (!password) {
            document.getElementById('password').focus();
        }
    } else {
        const userList = JSON.parse(localStorage.getItem('userList')) || [];
        const user = {
            userName: username,
            pwd: password
        };
        if (userList.find(user => user.userName === username)) {
            showAlert('User Name already taken, choose another Name and Try Again');
            document.getElementById('username').focus();
        } else {
            userList.push(user);
            localStorage.setItem('userList', JSON.stringify(userList));
            showAlert('User is Created');
            console.log(userList); // Log the userList to the console
        }
    }
});

const resetButton = document.getElementById('resetBtn');
if (resetButton) {
    resetButton.addEventListener('click', function() {
        localStorage.clear();
        showAlert('Storage cleared');
    });
}

document.getElementById('password').addEventListener('paste', function(e) {
    e.preventDefault();
});