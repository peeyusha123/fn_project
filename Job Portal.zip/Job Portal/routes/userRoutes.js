// routes/userRoutes.js

import express from "express";
import {
    showLogin,
    loginUser,
    showRegister,
    registerUser,
    logoutUser,
    showHome // Import showHome controller function
} from "../Controller/userController.js";

const router = express.Router();

// Route for the homepage
router.get("/", showHome);

// Routes for Login
router.get("/login", showLogin);    // Display login page
router.post("/login", loginUser);   // Handle login form submission

// Routes for Register
router.get("/register", showRegister); // Display registration page
router.post("/register", registerUser); // Handle registration form submission

// Route for Logout
router.get("/logout", logoutUser);  // Handle logout

export default router;