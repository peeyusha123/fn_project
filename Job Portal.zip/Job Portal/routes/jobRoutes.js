// routes/jobRoutes.js

import express from "express";
import { showJobs, showJobForm, createJob } from "../Controller/jobController.js";
import { isAuthenticated } from "../middlerware/authmiddleware.js" // Import or define auth middleware

const router = express.Router();

// Route to display all jobs
// Applying isAuthenticated middleware here instead of inside the controller function array
router.get("/jobs", isAuthenticated, showJobs); // GET /jobs - Display list of jobs

// Routes for creating a new job
router.get("/jobs/new", showJobForm); // GET /jobs/new - Display form to create new job
router.post("/jobs", createJob);     // POST /jobs - Handle submission of new job form

// Add routes for viewing single job, updating, deleting later if needed
// Example: router.get("/jobs/:id", isAuthenticated, showJobDetails);

export default router;