// app.js

import express from "express";
import session from "express-session";
import path from "path";
import { fileURLToPath } from "url";
import cookieParser from "cookie-parser";

// Import route handlers
import userRoutes from "./routes/userRoutes.js";
import jobRoutes from "./routes/jobRoutes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000; // Use environment variable for port if available

// --- Middleware ---

// Configure EJS as the view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views")); // Set the directory for EJS templates

// Serve static files from 'public' directory (CSS, client-side JS, images)
app.use(express.static(path.join(__dirname, "public")));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: true }));

// Parse Cookie header and populate req.cookies
app.use(cookieParser());

// Configure express-session middleware
app.use(session({
    secret: process.env.SESSION_SECRET || "mysecrekey", // Use environment variable for secret
    resave: false,
    saveUninitialized: true,
    cookie: { secure: process.env.NODE_ENV === 'production' } // Set secure: true only in production (HTTPS)
}));

// Middleware to make session user available in all EJS templates globally
// This avoids having to pass { user: req.session.user } in every res.render()
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// --- Routes ---

// Mount user routes (handles /, /login, /register, /logout)
app.use("/", userRoutes);

// Mount job routes (handles /jobs, /jobs/new)
app.use("/", jobRoutes);

// --- Basic 404 Handler (Optional but Recommended) ---
// This should be after all your routes
app.use((req, res) => {
    res.status(404).render('error', { message: 'Page Not Found' }); // Assuming you have views/error.ejs
});

// --- Basic Error Handler (Optional but Recommended) ---
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', { message: 'Something went wrong!' }); // Generic error page
});


// --- Server Listener ---
app.listen(PORT, () => {
    console.log(`Server Running on http://localhost:${PORT}`);
    // Added current time and location context as requested
    console.log(`Current Time: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} (IST)`);
    console.log(`Location Context: Tirupati, Andhra Pradesh, India`);
});