// middleware/authMiddleware.js

export const isAuthenticated = (req, res, next) => {
    // Check if user session exists
    if (req.session && req.session.user) {
        // User is authenticated, proceed to the next middleware or route handler
        return next();
    }
    // User is not authenticated, redirect to login page
    res.redirect('/login');
};

// You can add other middleware functions here later if needed