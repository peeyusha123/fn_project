// models/Job.js

// CHANGE: Added sample jobs with more details matching the screenshot (location, salary, skills)
const jobs = [
    {
        id: '1',
        title: 'Tech SDE',
        description: 'Seeking a skilled SDE for web development.', // Added sample description
        company: 'Coding Ninjas',
        location: 'Gurgaon HR IND Remote', // Added location
        salary: '₹ 14-20lpa', // Added salary
        skills: ['REACT', 'NodeJS', 'JS', 'SQL', 'MongoDB', 'Express', 'AWS'], // Added skills array
        postedBy: 'Recruiter A', // Sample recruiter
        status: 'Actively hiring' // Added status
    },
    {
        id: '2',
        title: 'Tech Angular Developer',
        description: 'Join our team as an Angular Developer.', // Added sample description
        company: 'Go Digit',
        location: 'Pune IND On-Site', // Added location
        salary: '₹ 6–10 lpa', // Added salary
        skills: ['Angular', 'JS', 'SQL', 'MongoDB', 'Express', 'AWS'], // Added skills array
        postedBy: 'Recruiter B', // Sample recruiter
        status: 'Actively hiring' // Added status
    },
    {
        id: '3',
        title: 'Tech SDE',
        description: 'Exciting opportunity for a Software Development Engineer.', // Added sample description
        company: 'Juspay',
        location: 'Bangalore IND', // Added location
        salary: '₹ 20–26 lpa', // Added salary
        skills: ['REACT', 'NodeJS', 'JS', 'SQL', 'MongoDB', 'Express', 'AWS'], // Added skills array
        postedBy: 'Recruiter C', // Sample recruiter
        status: 'Actively hiring' // Added status
    }
];

// Function to add a new job (ensure new jobs also have these fields)
export const addJob = (jobData) => {
    const newJob = {
        id: Date.now().toString(),
        title: jobData.title || 'N/A',
        description: jobData.description || 'N/A',
        company: jobData.company || 'N/A',
        location: jobData.location || 'N/A', // Default value
        salary: jobData.salary || 'N/A',     // Default value
        skills: jobData.skills || [],       // Default value (empty array)
        postedBy: jobData.postedBy || 'Admin', // Default value
        status: jobData.status || 'Actively hiring' // Default value
    };
    jobs.push(newJob);
    console.log("Job Added:", newJob); // For debugging
    console.log("Current Jobs:", jobs); // For debugging
};

// Function to get all jobs
export const getAllJobs = () => {
    return jobs;
};

// Add other functions if needed (get job by ID, update job, delete job)