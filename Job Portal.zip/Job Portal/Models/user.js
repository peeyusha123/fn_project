export const users = [{id:1 , name: "xyz" , email:"xyz@gmail.com", password:"12345" }]

export const addUser = (userData) =>{
    users.push(userData);
};

export const getUserByEmail = (email) =>{
    return users.find(user => user.email === email);
};

export const validateUser = (email,password) =>{
    return users.find(user => user.email === email && user.password === password);
};

export const getAllusers = () => users;