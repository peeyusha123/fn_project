// controllers/jobController.js
import { addJob, getAllJobs } from "../Models/job.js"; // Corrected import path/name


// Display All Jobs (Protected Route)
export const showJobs = [
    // You can apply middleware directly here if needed, or apply it in jobRoutes.js
    // isAuthenticated, // Uncomment if applying here
    (req, res) => {
        const jobs = getAllJobs();
        // The 'user' object is available globally via res.locals from middleware in app.js
        res.render("jobs/index", { jobs }); // Pass the jobs array to the view
    }
];

// Display New Job Form (Protected Route)
export const showJobForm = (req, res) => {
    res.render("jobs/new");
};

// Handle Creation of New Job (Protected Route)
export const createJob = (req, res) => {
    // Check if user is logged in (session check is good practice even if route is protected)
    if (!req.session || !req.session.user) {
         // This might be redundant if isAuthenticated middleware works, but good defense
         return res.redirect('/login');
    }

    const { title, description, company, location, salary, skills } = req.body;
    const jobData = {
        title,
        description,
        company,
        location,
        salary,
        // Ensure skills are processed correctly (example: comma-separated string)
        skills: skills ? skills.split(',').map(s => s.trim()) : [],
        // Safely access user name from session
        postedBy: req.session.user.name || 'Unknown User',
        status: 'Actively hiring'
    };
    addJob(jobData);
    res.redirect("/jobs");
};