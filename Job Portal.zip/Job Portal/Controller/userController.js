// controllers/userController.js
import { addUser, getUserByEmail, validateUser } from "../Models/user.js"; // Corrected import path/name

// Display Registration Page
export const showRegister = (req, res) => {
    // Render the registration view with error set to null initially
    res.render("users/register", { error: null });
};

// Handle User Registration
export const registerUser = (req, res) => {
    const { name, email, password } = req.body;
    const userExists = getUserByEmail(email);

    // Check if user already exists
    if (userExists) {
        // Re-render register page with an error message
        return res.render("users/register", { error: "User already exists with this email." });
    }

    // IMPORTANT: Hash password before saving in a real application
    // Example using a placeholder function: const hashedPassword = hashPassword(password);
    const newUser = { id: Date.now().toString(), name, email, password /* Store hashedPassword */ };
    addUser(newUser);

    // Redirect to login page after successful registration
    // It's generally better not to log in automatically after registration for verification flows
    res.redirect("/login");
};

// Display Login Page
export const showLogin = (req, res) => {
    // Render the login view with error set to null initially
    res.render("users/login", { error: null });
};

// Handle User Login
export const loginUser = (req, res) => {
    const { email, password } = req.body;

    // IMPORTANT: In validation, compare hashed password
    const validUser = validateUser(email, password);

    // Check if user is valid
    if (!validUser) {
        // Re-render login page with an error message
        return res.render("users/login", { error: "Invalid email or password." });
    }

    // Store user information in session upon successful login
    // Only store necessary, non-sensitive information
    req.session.user = {
        id: validUser.id,
        name: validUser.name,
        email: validUser.email
        // DO NOT store password in session
    };

    // Redirect to the job listings page after successful login
    res.redirect("/jobs");
};

// Handle User Logout
export const logoutUser = (req, res) => {
    req.session.destroy((err) => { // Destroy the session
        if (err) {
            console.error("Session destruction error:", err);
            // Even if error occurs, attempt to clear cookie and redirect
        }
        // Ensure cookies are cleared (name depends on session middleware config, 'connect.sid' is default)
        res.clearCookie('connect.sid');
        // Redirect to login page after logout
        res.redirect("/login");
    });
};

// Display Home Page (Moved here from app.js for consistency)
export const showHome = (req, res) => {
    res.render('home'); // Renders views/home.ejs
};