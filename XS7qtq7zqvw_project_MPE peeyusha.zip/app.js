import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import ejsLayouts from 'express-ejs-layouts';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import flash from 'connect-flash';
import methodOverride from 'method-override';
import dotenv from 'dotenv';

// Import routes
import authRoutes from './routes/auth.js';
import jobRoutes from './routes/jobs.js';
import recruiterRoutes from './routes/recruiters.js';
import jobSeekerRoutes from './routes/jobSeekers.js';

// Import middlewares
import { checkUserLoggedIn, trackLastVisit } from './middlewares/auth.js';

// Configure environment variables
dotenv.config();

// Create Express app
const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configure Express
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(methodOverride('_method'));
app.use(express.static(join(__dirname, 'public')));

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'views'));
app.use(ejsLayouts);
app.set('layout', 'layouts/main');

// Configure session
app.use(session({
  secret: process.env.SESSION_SECRET || 'job-portal-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// Configure flash messages
app.use(flash());

// Set global variables
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.user = req.session.user || null;
  next();
});

// Track last visit
app.use(trackLastVisit);

// Routes
app.get('/', (req, res) => {
  res.render('index', { 
    title: 'JobPortal - Find Your Dream Job',
    layout: 'layouts/main'
  });
});

app.use('/auth', authRoutes);
app.use('/jobs', jobRoutes);
app.use('/recruiter', checkUserLoggedIn, recruiterRoutes);
app.use('/job-seeker', jobSeekerRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).render('error', { 
    title: 'Page Not Found',
    message: 'The page you are looking for does not exist.',
    layout: 'layouts/main'
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { 
    title: 'Server Error',
    message: 'Something went wrong on our end. Please try again later.',
    layout: 'layouts/main'
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;