// Check if user is logged in
const checkUserLoggedIn = (req, res, next) => {
  if (!req.session.user) {
    req.flash('error_msg', 'Please log in to access this resource');
    return res.redirect('/auth/login');
  }
  next();
};

// Check if user is not logged in
const checkUserNotLoggedIn = (req, res, next) => {
  if (req.session.user) {
    return res.redirect('/');
  }
  next();
};

// Check user role
const checkUserRole = (role) => {
  return (req, res, next) => {
    if (!req.session.user) {
      req.flash('error_msg', 'Please log in to access this resource');
      return res.redirect('/auth/login');
    }
    
    if (req.session.user.role !== role) {
      req.flash('error_msg', 'You are not authorized to access this resource');
      return res.redirect('/');
    }
    
    next();
  };
};

// Track last visit using cookies
const trackLastVisit = (req, res, next) => {
  const lastVisit = req.cookies.lastVisit;
  
  if (lastVisit) {
    res.locals.lastVisit = new Date(parseInt(lastVisit));
  }
  
  // Set cookie for current visit
  res.cookie('lastVisit', Date.now(), {
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    httpOnly: true
  });
  
  next();
};

export {
  checkUserLoggedIn,
  checkUserNotLoggedIn,
  checkUserRole,
  trackLastVisit
};