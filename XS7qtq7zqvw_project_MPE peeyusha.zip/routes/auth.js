import express from 'express';
import { register, renderRegister, login, renderLogin, logout, getProfile } from '../controllers/authController.js';
import { checkUserLoggedIn, checkUserNotLoggedIn } from '../middlewares/auth.js';

const router = express.Router();

// Register routes
router.get('/register', checkUserNotLoggedIn, renderRegister);
router.post('/register', checkUserNotLoggedIn, register);

// Login routes
router.get('/login', checkUserNotLoggedIn, renderLogin);
router.post('/login', checkUserNotLoggedIn, login);

// Logout route
router.get('/logout', checkUserLoggedIn, logout);

// Profile route
router.get('/profile', checkUserLoggedIn, getProfile);

export default router;