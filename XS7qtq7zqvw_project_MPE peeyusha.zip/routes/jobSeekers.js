import express from 'express';
import { renderDashboard, renderApplications, renderSavedJobs } from '../controllers/jobSeekerController.js';
import { checkUserLoggedIn, checkUserRole } from '../middlewares/auth.js';

const router = express.Router();

// Check if user is logged in
router.use(checkUserLoggedIn);

// Check if user is a job seeker
router.use(checkUserRole('job-seeker'));

// Dashboard route
router.get('/dashboard', renderDashboard);

// Applications routes
router.get('/applications', renderApplications);

// Saved jobs routes
router.get('/saved-jobs', renderSavedJobs);

export default router;