import express from 'express';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { getJobs, getJobDetails, renderApplyJob, applyForJob, searchJobListings } from '../controllers/jobController.js';
import { checkUserLoggedIn } from '../middlewares/auth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configure multer for resume uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadsDir = join(__dirname, '../public/uploads/resumes');
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const extension = file.originalname.split('.').pop();
    cb(null, `${req.session.user.id}-${uniqueSuffix}.${extension}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype === 'application/pdf' ||
      file.mimetype === 'application/msword' ||
      file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ) {
      cb(null, true);
    } else {
      cb(new Error('Only PDF and Word documents are allowed'), false);
    }
  }
});

const router = express.Router();

// Job listing routes
router.get('/', getJobs);
router.get('/search', searchJobListings);
router.get('/:id', getJobDetails);

// Job application routes (protected)
router.get('/:id/apply', checkUserLoggedIn, renderApplyJob);
router.post('/:id/apply', checkUserLoggedIn, upload.single('resume'), applyForJob);

export default router;