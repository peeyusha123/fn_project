import express from 'express';
import { renderDashboard, renderJobs, renderStats } from '../controllers/recruiterController.js';
import { renderCreateJob, createNewJob, renderEditJob, updateJobDetails, deleteJobListing, getJobApplicants } from '../controllers/jobController.js';
import { checkUserRole } from '../middlewares/auth.js';

const router = express.Router();

// Check if user is a recruiter
router.use(checkUserRole('recruiter'));

// Dashboard route
router.get('/dashboard', renderDashboard);

// Jobs routes
router.get('/jobs', renderJobs);
router.get('/jobs/create', renderCreateJob);
router.post('/jobs/create', createNewJob);
router.get('/jobs/:id/edit', renderEditJob);
router.put('/jobs/:id', updateJobDetails);
router.delete('/jobs/:id', deleteJobListing);
router.get('/jobs/:id/applicants', getJobApplicants);

// Stats route
router.get('/stats', renderStats);

export default router;