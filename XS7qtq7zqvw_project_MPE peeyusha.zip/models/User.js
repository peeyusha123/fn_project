import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';
import fs from 'fs/promises';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Path to the users data file
const dataPath = join(__dirname, '../data/users.json');

// Ensure data directory exists
const ensureDataDir = async () => {
  const dataDir = join(__dirname, '../data');
  try {
    await fs.access(dataDir);
  } catch (error) {
    await fs.mkdir(dataDir, { recursive: true });
  }
};

// Initialize users data file if it doesn't exist
const initDataFile = async () => {
  try {
    await fs.access(dataPath);
  } catch (error) {
    await fs.writeFile(dataPath, JSON.stringify([], null, 2));
  }
};

// Get all users
const getAllUsers = async () => {
  await ensureDataDir();
  await initDataFile();
  
  const data = await fs.readFile(dataPath, 'utf8');
  return JSON.parse(data);
};

// Save users
const saveUsers = async (users) => {
  await ensureDataDir();
  await fs.writeFile(dataPath, JSON.stringify(users, null, 2));
};

// Add new user
const addUser = async (userData) => {
  const users = await getAllUsers();
  
  // Check if user with email already exists
  const existingUser = users.find(user => user.email === userData.email);
  if (existingUser) {
    throw new Error('User with this email already exists');
  }
  
  // Hash password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(userData.password, salt);
  
  // Create new user
  const newUser = {
    id: uuidv4(),
    name: userData.name,
    email: userData.email,
    password: hashedPassword,
    role: userData.role || 'job-seeker', // Default role
    created_at: new Date().toISOString(),
    applications: [],
    jobs: []
  };
  
  users.push(newUser);
  await saveUsers(users);
  
  // Return user without password
  const { password, ...userWithoutPassword } = newUser;
  return userWithoutPassword;
};

// Get user by ID
const getUserById = async (id) => {
  const users = await getAllUsers();
  const user = users.find(user => user.id === id);
  
  if (!user) {
    return null;
  }
  
  // Return user without password
  const { password, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// Get user by email
const getUserByEmail = async (email) => {
  const users = await getAllUsers();
  return users.find(user => user.email === email);
};

// Login user
const loginUser = async (email, password) => {
  const user = await getUserByEmail(email);
  
  if (!user) {
    throw new Error('Invalid email or password');
  }
  
  const isMatch = await bcrypt.compare(password, user.password);
  
  if (!isMatch) {
    throw new Error('Invalid email or password');
  }
  
  // Return user without password
  const { password: pass, ...userWithoutPassword } = user;
  return userWithoutPassword;
};

// Update user
const updateUser = async (id, userData) => {
  const users = await getAllUsers();
  const index = users.findIndex(user => user.id === id);
  
  if (index === -1) {
    throw new Error('User not found');
  }
  
  // Update user data
  users[index] = {
    ...users[index],
    ...userData,
    updated_at: new Date().toISOString()
  };
  
  await saveUsers(users);
  
  // Return user without password
  const { password, ...userWithoutPassword } = users[index];
  return userWithoutPassword;
};

// Add job application to user
const addJobApplication = async (userId, jobId, resumePath) => {
  const users = await getAllUsers();
  const index = users.findIndex(user => user.id === userId);
  
  if (index === -1) {
    throw new Error('User not found');
  }
  
  // Add job application
  const application = {
    id: uuidv4(),
    jobId,
    resumePath,
    status: 'pending',
    applied_at: new Date().toISOString()
  };
  
  users[index].applications = users[index].applications || [];
  users[index].applications.push(application);
  
  await saveUsers(users);
  return application;
};

// Add job posting to recruiter
const addJobPosting = async (userId, jobId) => {
  const users = await getAllUsers();
  const index = users.findIndex(user => user.id === userId);
  
  if (index === -1) {
    throw new Error('User not found');
  }
  
  if (users[index].role !== 'recruiter') {
    throw new Error('Only recruiters can post jobs');
  }
  
  // Add job posting
  users[index].jobs = users[index].jobs || [];
  users[index].jobs.push(jobId);
  
  await saveUsers(users);
  return users[index];
};

export {
  getAllUsers,
  addUser,
  getUserById,
  getUserByEmail,
  loginUser,
  updateUser,
  addJobApplication,
  addJobPosting
};