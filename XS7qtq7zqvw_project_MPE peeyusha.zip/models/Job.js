import { v4 as uuidv4 } from 'uuid';
import fs from 'fs/promises';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Path to the jobs data file
const dataPath = join(__dirname, '../data/jobs.json');

// Ensure data directory exists
const ensureDataDir = async () => {
  const dataDir = join(__dirname, '../data');
  try {
    await fs.access(dataDir);
  } catch (error) {
    await fs.mkdir(dataDir, { recursive: true });
  }
};

// Initialize jobs data file if it doesn't exist
const initDataFile = async () => {
  try {
    await fs.access(dataPath);
  } catch (error) {
    await fs.writeFile(dataPath, JSON.stringify([], null, 2));
  }
};

// Get all jobs
const getAllJobs = async () => {
  await ensureDataDir();
  await initDataFile();
  
  const data = await fs.readFile(dataPath, 'utf8');
  return JSON.parse(data);
};

// Save jobs
const saveJobs = async (jobs) => {
  await ensureDataDir();
  await fs.writeFile(dataPath, JSON.stringify(jobs, null, 2));
};

// Create new job
const createJob = async (jobData) => {
  const jobs = await getAllJobs();
  
  // Create new job
  const newJob = {
    id: uuidv4(),
    title: jobData.title,
    company: jobData.company,
    location: jobData.location,
    type: jobData.type || 'Full-time',
    description: jobData.description,
    requirements: jobData.requirements,
    salary: jobData.salary,
    contact_email: jobData.contact_email,
    recruiter_id: jobData.recruiter_id,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    is_active: true,
    applicants: []
  };
  
  jobs.push(newJob);
  await saveJobs(jobs);
  
  return newJob;
};

// Get job by ID
const getJobById = async (id) => {
  const jobs = await getAllJobs();
  return jobs.find(job => job.id === id) || null;
};

// Get jobs by recruiter ID
const getJobsByRecruiterId = async (recruiterId) => {
  const jobs = await getAllJobs();
  return jobs.filter(job => job.recruiter_id === recruiterId);
};

// Update job
const updateJob = async (id, jobData) => {
  const jobs = await getAllJobs();
  const index = jobs.findIndex(job => job.id === id);
  
  if (index === -1) {
    throw new Error('Job not found');
  }
  
  // Update job data
  jobs[index] = {
    ...jobs[index],
    ...jobData,
    updated_at: new Date().toISOString()
  };
  
  await saveJobs(jobs);
  return jobs[index];
};

// Delete job
const deleteJob = async (id) => {
  const jobs = await getAllJobs();
  const index = jobs.findIndex(job => job.id === id);
  
  if (index === -1) {
    throw new Error('Job not found');
  }
  
  // Remove job
  const deletedJob = jobs.splice(index, 1)[0];
  await saveJobs(jobs);
  
  return deletedJob;
};

// Add applicant to job
const addApplicant = async (jobId, applicant) => {
  const jobs = await getAllJobs();
  const index = jobs.findIndex(job => job.id === jobId);
  
  if (index === -1) {
    throw new Error('Job not found');
  }
  
  // Add applicant to job
  jobs[index].applicants = jobs[index].applicants || [];
  jobs[index].applicants.push(applicant);
  
  await saveJobs(jobs);
  return jobs[index];
};

// Get applicants for a job
const getApplicants = async (jobId) => {
  const job = await getJobById(jobId);
  
  if (!job) {
    throw new Error('Job not found');
  }
  
  return job.applicants || [];
};

// Search jobs by title, company, or location
const searchJobs = async (query) => {
  const jobs = await getAllJobs();
  const lowerQuery = query.toLowerCase();
  
  return jobs.filter(job => 
    job.title.toLowerCase().includes(lowerQuery) ||
    job.company.toLowerCase().includes(lowerQuery) ||
    job.location.toLowerCase().includes(lowerQuery) ||
    job.description.toLowerCase().includes(lowerQuery)
  );
};

export {
  getAllJobs,
  createJob,
  getJobById,
  getJobsByRecruiterId,
  updateJob,
  deleteJob,
  addApplicant,
  getApplicants,
  searchJobs
};