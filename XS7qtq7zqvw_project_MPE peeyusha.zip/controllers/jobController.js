import { getAllJobs, getJobById, createJob, updateJob, deleteJob, addApplicant, getApplicants, searchJobs } from '../models/Job.js';
import { addJobApplication, addJobPosting, getUserById } from '../models/User.js';
import { sendApplicationConfirmation } from '../utils/mailer.js';

// Get all jobs
const getJobs = async (req, res) => {
  try {
    const jobs = await getAllJobs();
    res.render('jobs/index', {
      title: 'All Jobs',
      jobs,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load jobs');
    res.redirect('/');
  }
};

// Get job details
const getJobDetails = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await getJobById(jobId);
    
    if (!job) {
      req.flash('error_msg', 'Job not found');
      return res.redirect('/jobs');
    }
    
    res.render('jobs/details', {
      title: job.title,
      job,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load job details');
    res.redirect('/jobs');
  }
};

// Render job creation form
const renderCreateJob = (req, res) => {
  res.render('jobs/create', {
    title: 'Post a New Job',
    layout: 'layouts/main'
  });
};

// Create a new job
const createNewJob = async (req, res) => {
  try {
    const recruiterId = req.session.user.id;
    const { title, company, location, type, description, requirements, salary, contact_email } = req.body;
    
    // Validate inputs
    if (!title || !company || !location || !description) {
      req.flash('error_msg', 'Please fill in all required fields');
      return res.redirect('/recruiter/jobs/create');
    }
    
    // Create job
    const job = await createJob({
      title,
      company,
      location,
      type,
      description,
      requirements,
      salary,
      contact_email,
      recruiter_id: recruiterId
    });
    
    // Add job to recruiter's listings
    await addJobPosting(recruiterId, job.id);
    
    req.flash('success_msg', 'Job posted successfully');
    res.redirect(`/recruiter/jobs`);
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to create job');
    res.redirect('/recruiter/jobs/create');
  }
};

// Render job edit form
const renderEditJob = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await getJobById(jobId);
    
    if (!job) {
      req.flash('error_msg', 'Job not found');
      return res.redirect('/recruiter/jobs');
    }
    
    // Check if job belongs to recruiter
    if (job.recruiter_id !== req.session.user.id) {
      req.flash('error_msg', 'Unauthorized');
      return res.redirect('/recruiter/jobs');
    }
    
    res.render('jobs/edit', {
      title: 'Edit Job',
      job,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load job');
    res.redirect('/recruiter/jobs');
  }
};

// Update job
const updateJobDetails = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await getJobById(jobId);
    
    if (!job) {
      req.flash('error_msg', 'Job not found');
      return res.redirect('/recruiter/jobs');
    }
    
    // Check if job belongs to recruiter
    if (job.recruiter_id !== req.session.user.id) {
      req.flash('error_msg', 'Unauthorized');
      return res.redirect('/recruiter/jobs');
    }
    
    const { title, company, location, type, description, requirements, salary, contact_email, is_active } = req.body;
    
    // Update job
    await updateJob(jobId, {
      title,
      company,
      location,
      type,
      description,
      requirements,
      salary,
      contact_email,
      is_active: is_active === 'true'
    });
    
    req.flash('success_msg', 'Job updated successfully');
    res.redirect('/recruiter/jobs');
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to update job');
    res.redirect(`/recruiter/jobs/${req.params.id}/edit`);
  }
};

// Delete job
const deleteJobListing = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await getJobById(jobId);
    
    if (!job) {
      req.flash('error_msg', 'Job not found');
      return res.redirect('/recruiter/jobs');
    }
    
    // Check if job belongs to recruiter
    if (job.recruiter_id !== req.session.user.id) {
      req.flash('error_msg', 'Unauthorized');
      return res.redirect('/recruiter/jobs');
    }
    
    // Delete job
    await deleteJob(jobId);
    
    req.flash('success_msg', 'Job deleted successfully');
    res.redirect('/recruiter/jobs');
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to delete job');
    res.redirect('/recruiter/jobs');
  }
};

// Render job application form
const renderApplyJob = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await getJobById(jobId);
    
    if (!job) {
      req.flash('error_msg', 'Job not found');
      return res.redirect('/jobs');
    }
    
    res.render('jobs/apply', {
      title: `Apply for ${job.title}`,
      job,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load application form');
    res.redirect('/jobs');
  }
};

// Apply for job
const applyForJob = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await getJobById(jobId);
    
    if (!job) {
      req.flash('error_msg', 'Job not found');
      return res.redirect('/jobs');
    }
    
    // Check if resume was uploaded
    if (!req.file) {
      req.flash('error_msg', 'Please upload your resume');
      return res.redirect(`/jobs/${jobId}/apply`);
    }
    
    const userId = req.session.user.id;
    const user = await getUserById(userId);
    
    if (!user) {
      req.flash('error_msg', 'User not found');
      return res.redirect('/auth/login');
    }
    
    // Create applicant object
    const applicant = {
      id: userId,
      name: user.name,
      email: user.email,
      resumePath: req.file.path,
      applied_at: new Date().toISOString(),
      status: 'pending'
    };
    
    // Add applicant to job
    await addApplicant(jobId, applicant);
    
    // Add job application to user
    await addJobApplication(userId, jobId, req.file.path);
    
    // Send confirmation email
    await sendApplicationConfirmation(user.email, job);
    
    req.flash('success_msg', 'Application submitted successfully');
    res.redirect('/job-seeker/applications');
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to submit application');
    res.redirect(`/jobs/${req.params.id}/apply`);
  }
};

// Get job applicants (for recruiters)
const getJobApplicants = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await getJobById(jobId);
    
    if (!job) {
      req.flash('error_msg', 'Job not found');
      return res.redirect('/recruiter/jobs');
    }
    
    // Check if job belongs to recruiter
    if (job.recruiter_id !== req.session.user.id) {
      req.flash('error_msg', 'Unauthorized');
      return res.redirect('/recruiter/jobs');
    }
    
    // Get applicants
    const applicants = job.applicants || [];
    
    res.render('jobs/applicants', {
      title: `Applicants for ${job.title}`,
      job,
      applicants,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load applicants');
    res.redirect('/recruiter/jobs');
  }
};

// Search for jobs
const searchJobListings = async (req, res) => {
  try {
    const query = req.query.q;
    
    if (!query) {
      return res.redirect('/jobs');
    }
    
    const jobs = await searchJobs(query);
    
    res.render('jobs/search', {
      title: 'Search Results',
      jobs,
      query,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to search jobs');
    res.redirect('/jobs');
  }
};

export {
  getJobs,
  getJobDetails,
  renderCreateJob,
  createNewJob,
  renderEditJob,
  updateJobDetails,
  deleteJobListing,
  renderApplyJob,
  applyForJob,
  getJobApplicants,
  searchJobListings
};