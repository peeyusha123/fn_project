import { getUserById } from '../models/User.js';
import { getJobById, getAllJobs } from '../models/Job.js';

// Render job seeker dashboard
const renderDashboard = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const user = await getUserById(userId);
    
    if (!user) {
      req.flash('error_msg', 'User not found');
      return res.redirect('/');
    }
    
    // Get recent jobs
    const allJobs = await getAllJobs();
    const recentJobs = allJobs
      .filter(job => job.is_active)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 5);
    
    // Get user applications
    const applications = user.applications || [];
    const recentApplications = [...applications]
      .sort((a, b) => new Date(b.applied_at) - new Date(a.applied_at))
      .slice(0, 3);
    
    // Enrich applications with job data
    for (const app of recentApplications) {
      const job = await getJobById(app.jobId);
      app.job = job;
    }
    
    res.render('job-seeker/dashboard', {
      title: 'Job Seeker Dashboard',
      user,
      recentJobs,
      recentApplications,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load dashboard');
    res.redirect('/');
  }
};

// Render job seeker applications
const renderApplications = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const user = await getUserById(userId);
    
    if (!user) {
      req.flash('error_msg', 'User not found');
      return res.redirect('/');
    }
    
    // Get all user applications
    const applications = user.applications || [];
    
    // Enrich applications with job data
    for (const app of applications) {
      const job = await getJobById(app.jobId);
      app.job = job;
    }
    
    // Sort applications by date (newest first)
    applications.sort((a, b) => new Date(b.applied_at) - new Date(a.applied_at));
    
    res.render('job-seeker/applications', {
      title: 'My Applications',
      applications,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load applications');
    res.redirect('/job-seeker/dashboard');
  }
};

// Render saved jobs
const renderSavedJobs = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const user = await getUserById(userId);
    
    if (!user) {
      req.flash('error_msg', 'User not found');
      return res.redirect('/');
    }
    
    // Get saved jobs (This would normally be in the user model, but for simplicity we're returning an empty array)
    const savedJobs = [];
    
    res.render('job-seeker/saved-jobs', {
      title: 'Saved Jobs',
      savedJobs,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load saved jobs');
    res.redirect('/job-seeker/dashboard');
  }
};

export {
  renderDashboard,
  renderApplications,
  renderSavedJobs
};