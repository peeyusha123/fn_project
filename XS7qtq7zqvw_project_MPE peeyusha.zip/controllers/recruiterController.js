import { getJobsByRecruiterId } from '../models/Job.js';
import { getUserById } from '../models/User.js';

// Render recruiter dashboard
const renderDashboard = async (req, res) => {
  try {
    const recruiterId = req.session.user.id;
    const recruiter = await getUserById(recruiterId);
    
    if (!recruiter || recruiter.role !== 'recruiter') {
      req.flash('error_msg', 'Unauthorized');
      return res.redirect('/');
    }
    
    const jobs = await getJobsByRecruiterId(recruiterId);
    
    // Get some statistics
    const activeJobs = jobs.filter(job => job.is_active).length;
    const totalApplicants = jobs.reduce((total, job) => total + (job.applicants ? job.applicants.length : 0), 0);
    
    res.render('recruiter/dashboard', {
      title: 'Recruiter Dashboard',
      recruiter,
      jobs,
      activeJobs,
      totalApplicants,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load dashboard');
    res.redirect('/');
  }
};

// Render recruiter's job listings
const renderJobs = async (req, res) => {
  try {
    const recruiterId = req.session.user.id;
    const jobs = await getJobsByRecruiterId(recruiterId);
    
    res.render('recruiter/jobs', {
      title: 'My Job Postings',
      jobs,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load jobs');
    res.redirect('/recruiter/dashboard');
  }
};

// Render recruiter stats
const renderStats = async (req, res) => {
  try {
    const recruiterId = req.session.user.id;
    const jobs = await getJobsByRecruiterId(recruiterId);
    
    // Calculate stats
    const totalJobs = jobs.length;
    const activeJobs = jobs.filter(job => job.is_active).length;
    const totalApplicants = jobs.reduce((total, job) => total + (job.applicants ? job.applicants.length : 0), 0);
    
    // Top jobs by applicants
    const topJobs = [...jobs]
      .sort((a, b) => (b.applicants ? b.applicants.length : 0) - (a.applicants ? a.applicants.length : 0))
      .slice(0, 5);
    
    res.render('recruiter/stats', {
      title: 'Recruitment Statistics',
      totalJobs,
      activeJobs,
      totalApplicants,
      topJobs,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load statistics');
    res.redirect('/recruiter/dashboard');
  }
};

export {
  renderDashboard,
  renderJobs,
  renderStats
};