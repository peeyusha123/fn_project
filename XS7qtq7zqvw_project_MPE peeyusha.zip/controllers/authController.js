import { addUser, loginUser, getUserById } from '../models/User.js';

// Handle user registration
const register = async (req, res) => {
  try {
    const { name, email, password, confirm_password, role } = req.body;
    
    // Validate inputs
    const errors = [];
    
    if (!name || !email || !password || !confirm_password) {
      errors.push({ msg: 'All fields are required' });
    }
    
    if (password !== confirm_password) {
      errors.push({ msg: 'Passwords do not match' });
    }
    
    if (password.length < 6) {
      errors.push({ msg: 'Password should be at least 6 characters' });
    }
    
    if (errors.length > 0) {
      return res.render('auth/register', {
        title: 'Register',
        errors,
        name,
        email,
        role,
        layout: 'layouts/auth'
      });
    }
    
    // Create new user
    const user = await addUser({
      name,
      email,
      password,
      role: role || 'job-seeker'
    });
    
    req.flash('success_msg', 'You are now registered and can log in');
    res.redirect('/auth/login');
  } catch (error) {
    console.error(error);
    req.flash('error_msg', error.message);
    res.redirect('/auth/register');
  }
};

// Render registration page
const renderRegister = (req, res) => {
  res.render('auth/register', {
    title: 'Register',
    layout: 'layouts/auth'
  });
};

// Handle user login
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Validate inputs
    if (!email || !password) {
      req.flash('error_msg', 'All fields are required');
      return res.redirect('/auth/login');
    }
    
    // Attempt login
    const user = await loginUser(email, password);
    
    // Set user session
    req.session.user = user;
    
    // Redirect based on role
    if (user.role === 'recruiter') {
      res.redirect('/recruiter/dashboard');
    } else {
      res.redirect('/job-seeker/dashboard');
    }
  } catch (error) {
    console.error(error);
    req.flash('error_msg', error.message);
    res.redirect('/auth/login');
  }
};

// Render login page
const renderLogin = (req, res) => {
  res.render('auth/login', {
    title: 'Login',
    layout: 'layouts/auth'
  });
};

// Handle user logout
const logout = (req, res) => {
  req.session.destroy();
  res.redirect('/');
};

// Get current user profile
const getProfile = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const user = await getUserById(userId);
    
    if (!user) {
      req.flash('error_msg', 'User not found');
      return res.redirect('/');
    }
    
    res.render('auth/profile', {
      title: 'My Profile',
      user,
      layout: 'layouts/main'
    });
  } catch (error) {
    console.error(error);
    req.flash('error_msg', 'Failed to load profile');
    res.redirect('/');
  }
};

export {
  register,
  renderRegister,
  login,
  renderLogin,
  logout,
  getProfile
};